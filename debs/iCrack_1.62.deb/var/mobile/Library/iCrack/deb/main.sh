#!/bin/bash
cd ./deb

if [ ! -e /usr/bin/sudo ]
then
echo "
我检测到了你的机器上没有安装sudo，
iCrack不能完美地工作
hzy想得真周到，为你集成了sudo_1.6.9p12-4"
dpkg -i sudo*.deb
fi

if [ ! -e /usr/bin/zip ]
then
echo "我检测到了你的机器上没有安装zip，
iCrack不能完美地工作
hzy想得真周到，为你集成了zip_2.32-5"
dpkg -i zip*.deb
fi

if [ ! -e /usr/bin/unzip ]
then
echo "
我检测到了你的机器上没有安装unzip，
iCrack不能完美地工作（强制破解工具需要它）
hzy想得真周到，为你集成了zip_2.32-5"
dpkg -i unzip*.deb
fi

if [ ! -e /usr/bin/plutil ]
then
echo "
我检测到了你的机器上没有安装erica utilities(plutil)，
iCrack不能完美地工作
hzy想得真周到，为你集成了erica utilities_beta17"
dpkg -i erica_utilities*.deb
fi

echo "
首次使用，依赖库更新完毕！"
