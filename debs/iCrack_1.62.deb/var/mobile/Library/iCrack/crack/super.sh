#!/bin/bash
echo '啰嗦几句，这儿只能对已破解的App使用，iCrack会将其打包还原为ipa

你已经安装了以下app：
==============================='
cd /var/mobile/Applications
find */*.app -name *.app | cut -f 2 -d "/" | cut -f 1 -d "."
#一条搞了好久才整出来的命令

echo '===============================
哪一个是你想强制破解的，输入名字吧：
如果有空格，请用星号*将其代替'
read to
if [ ! -d ./*/$to.app ]
then
clear
echo "输入错误

无/var/mobile/Applications/*/$to.app这个目录
"
exit
fi
clear
echo '准备就绪啦！开始Crack！
下面便开始破解了，请耐心等待哦

时间略久，切勿中途退出！'
cd ./*/$to.app
cd ../
mkdir -p iCrack/Payload
mv iTunes* iCrack
if [ -d /var/mobile/Library/iCrack/set/rminfo ]
then
mv iCrack/iTunesMetadata.plist ./
fi
mv *.app iCrack/Payload
cd iCrack
zip -r -q ipa *
mv ipa.zip "/var/mobile/Media/iCrack/$to.By_`cat /var/mobile/Library/iCrack/set/usrname`.ipa"
mv iTunes* ../
mv Payload/*.app ../
cd ../
rm -r iCrack
clear
echo '成功！要的东西已被放入了/var/mobile/Media/iCrack下
浏览该文件夹：
==============================='
ls /var/mobile/Media/iCrack
echo '===============================

就这样，瞄……
'
exit