#!/bin/bash
cd crack
echo '准备就绪啦，
用彩色标出来的就是可以进行破解的程序:
（有的程序没显出来？那就得使用主菜单的「强制破解」啦）
'
./iCrack
echo '
请输入目标名称或代号：
如果想把这些程序全都破解，输入all吧：'
read app
clear
if [ $app = all ]
then
echo '准备好了吗？反正我是准备好了(^_^;)

随便键入点儿什么来让程序启动：'
read any
clear
echo '这下花的时间可就多了哦，
一定要隆重地把机器放在一旁等上几十分钟

哦，对了，可以用backgrounder让其后台运行着

！(◎_◎;)
'
./iCrack --
else
clear
echo '一切都是那么容易，那么方便，那么实用！
注＇此句使用了排比的修辞手法
'
./iCrack $app
fi
clear
echo '感谢运行这个程序，程序已经破解好了(^.^)'
mv /var/root/Documents/Cracked/*.ipa /var/mobile/Media/iCrack
echo '在/var/mobile/Media/iCrack中现在有这些文件：
'
ls /var/mobile/Media/iCrack
echo '
程序就此关闭，如有疑问，去主菜单的「关于」看看吧
(^_−)−☆
'
exit