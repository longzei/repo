#!/bin/bash
#by hzy1996

echo '首先，你需要App隐私保护吗？

生成的ipa我可以为你去掉说明文件，
别人添加到iTunes后就看不到多余的信息
你的Apple ID、购买价格和日期等不会泄露了
不过除了App图片、名称以外所有信息
诸如分类信息也没了会让用户感到不爽的

1｠我需要此功能
2｠我不要这样（默认）
'
read xz
if [ $xz = 1 ]
then
rm='YES'
mkdir -p ./rminfo
else
rm='NO'
if [ -d ./rminfo ]
then
rm -r ./rminfo
fi
fi

clear
echo "然后，请输入你的名字，这将打包进生成的ipa中
当前是`cat ./usrname`
"
read name

clear
echo '正在保存设置...'
cp -f ./head /etc/clutch.conf
echo "$name</string>
        <key>RemoveMetadata</key>
        <string>$rm</string>
</dict>
</plist>" >> /etc/clutch.conf
echo "$name" > ./usrname
echo '设置已生效！
'

exit