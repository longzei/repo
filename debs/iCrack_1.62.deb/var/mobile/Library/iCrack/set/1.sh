#!/bin/bash
#by hzy1996

echo "当前你的快捷设置是`cat ./run`
你想修改成什么呢？
（输入wc即可退出编辑:P）
"
read run
clear

had=0
if [ $run != "wc" ]
then
if [ -e /*in/$run ]
then
had=1
elif [ -e /usr/*in/$run ]
then
had=1
fi
if [ $had = 1 ]
then
echo "不行哦，$run是一条已经存在的系统命令，我可不敢动它
(･･;)
"
./1.sh
else
mv /bin/`cat ./run` /bin/$run
echo "$run" > ./run
echo "ok！你现在能同时使用icrack和$run来进入程序啦
（＾∇＾）
"
fi
fi

exit