#!/bin/bash
#by hzy1996

echo '建立成功！已经在小i根目录创建了一个快捷方式【iCrack】
链接指向/var/mobile/Media/iCrack
ヾ(＠⌒ー⌒＠)ノ'
if [ -e /【iCrack】 ]
then
rm /【iCrack】
fi
ln -s /var/mobile/Media/iCrack /【iCrack】

exit