#!/bin/bash
#by hzy1996
cd ./set

echo '请问你想进行哪项设置？

❶iCrack运行命令自定义
运行此程序可以在终端中输入icrack，你也可以改成其他命令

❷破解设置
对功能二、四及破解者名字进行设置

❸构建快捷方式
在根目录下生成指向/var/mobile/Media/iCrack的符号链接
方便查看破解的ipa

要干什么呢？'
read do

clear

if [ ! -e $do.sh ]
then
echo '输入错误，得仔细点哦^^;'
else
./$do.sh
fi

exit