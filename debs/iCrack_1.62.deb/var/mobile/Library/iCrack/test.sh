#!/bin/bash
if [ $(whoami) != "root" ]
then
echo '没提权？这可不行，
程序自动关掉了，快快去提权吧：

先输入su（回车）
密码默认是alpine(输入时不会回显)
然后再输入icrack即可进入程序
(⌒▽⌒)
'
killall bash
fi
exit